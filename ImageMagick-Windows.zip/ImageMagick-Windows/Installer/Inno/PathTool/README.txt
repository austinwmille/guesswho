The PathTool utility was written by  by ared Breland <jbreland@legroom.net>
and was retrieved from the URL "http://legroom.net/files/software/modpath.exe".

