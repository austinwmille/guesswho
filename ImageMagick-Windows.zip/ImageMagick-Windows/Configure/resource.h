//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by configure.rc
//
#define IDS_PROPSHT_CAPTION             101
#define IDR_MAINFRAME                   102

#define IDD_WELCOME_PAGE                104
#define IDD_TARGET_PAGE                 105
#define IDD_SYSTEM_PAGE                 106
#define IDD_FINISHED_PAGE               107

#define IDB_LOGO1                       132

#define IDC_WELCOME_TEXT                1000
#define IDC_PROJECT_DYNAMIC_MT          1001
#define IDC_PROJECT_STATIC_MT_DLL       1002
#define IDC_PROJECT_STATIC_MT           1003
#define IDC_PLATFORM                    1005
#define IDC_QUANTUM_DEPTH               1006
#define IDC_HDRI                        1007
#define IDC_VISUALSTUDIO                1008
#define IDC_POLICYCONFIG                1009
#define IDC_OPEN_MP                     1010
#define IDC_OPEN_CL                     1011
#define IDC_ENABLE_DPC                  1012
#define IDC_INCLUDE_OPTIONAL            1013
#define IDC_INCLUDE_INCOMPATIBLE        1014
#define IDC_EXCLUDE_DEPRECATED          1015
#define IDC_INSTALLED_SUPPORT           1016
#define IDC_ZERO_CONFIGURATION_SUPPORT  1017
#define IDC_FINISHED_TEXT               1018
#define IDD_WAITDIALOG                  1019
#define IDC_MSGCTRL                     1020
#define IDC_PROGRESSCTRL                1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
